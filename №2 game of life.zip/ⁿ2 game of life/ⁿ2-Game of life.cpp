/**
*
* Solution to course project # <����� �� �������>
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2023/2024
*
* @author ������ ������
* @idnumber 4MI0600392
* @compiler <compiler GCC>
*
* 
*
*/


#include <iostream>
#include <fstream>
#include <cstdlib> 

const int MAX_HEIGHT_SIZE = 24;
const int MAX_WIDTH_SIZE = 80;
const int ADJUSTMENT = 1;
const int MIN_X = 1;
const int MIN_Y = 1;
const int DOUBLE_DIGIT = 10;
const int MAX_FILE_NAME_SIZE = 128;
const int STARTING_WIDTH = 16;
const int STARTING_HEIGHT = 8;

void mainMenu(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int& x, int& y);

void resize(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int& x, int& y);

void crop(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int& x, int& y, char croppedField[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE]);

void stringToField(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE],char fileLine[MAX_WIDTH_SIZE],int x ,int y)
{
	for (int i = 0; i < x; ++i)
	{
		field[i][y] = fileLine[i]; //every row gets copied
	}
}

void save(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int& x, int& y) 
{
	char croppedField[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE] = {};

	crop(field, x, y, croppedField);

	char fileName[MAX_FILE_NAME_SIZE] = "";
	std::cin >> fileName;

	std::ofstream file;
	file.open(fileName);
	for (int i = 0; i < y; ++i)
	{
		for (int j = 0; j < x; ++j)
		{
			file << croppedField[j][i];
		}
		file << '\n';
	}
	file.close();
	std::cout << "Saved file: " << fileName << '\n';
}

void load(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE],int& x,int& y)
{
	x = 0;
	y = 0;

	char loadFileName[MAX_FILE_NAME_SIZE] = "";
	std::cin >> loadFileName;

	char fileLine[MAX_WIDTH_SIZE] = "";

	std::ifstream file;
	file.open(loadFileName);
	
	file >> fileLine;

	while (fileLine[x] != '\0')
	{
		++x;
	}

	while (fileLine[0] == '@' || fileLine[0] == '-')
	{
		stringToField(field, fileLine, x, y);
		++y;
		file >> fileLine;
	}
	file.close();
} 

int countAliveNeighbours(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int x, int y)
{
	int count = 0;

	for (int i = x - 1; i <= x + 1; i++) 
	{
		for (int j = y - 1; j <= y + 1; j++) 
		{
			if ((i >= 0 && i < MAX_WIDTH_SIZE) && (j >= 0 && j < MAX_HEIGHT_SIZE) && !(i == x && j == y))  
			{
				if (field[i][j] == '@')
				{
					count++;
				}
			}
		}
	}

	return count;
}

bool isLiving(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int x, int y)
{
	int aliveNeighbours = countAliveNeighbours(field, x, y);
	if ((aliveNeighbours == 2 && field[x][y] == '@') || aliveNeighbours == 3)
	{
		return true;
	}
	return false;
} // checks if a cell will die or be alive

void stepForward(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int& x,int& y)     //simulates a turn
{
	char newField[MAX_WIDTH_SIZE + ADJUSTMENT][MAX_HEIGHT_SIZE + ADJUSTMENT] = {};

	int newX = x;
	int newY = y;

	bool isAliveOnRow = false;
	bool isAliveOnColumn = false;

	for (int i = 0; i <= x; ++i)
	{
		for (int j = 0; j <= y; ++j)
		{
			if (i < MAX_WIDTH_SIZE && j < MAX_HEIGHT_SIZE)
			{
				newField[i][j] = isLiving(field, i, j) ? '@' : '-';
			}
		}
	}

	for (int m = 0; m <= x; ++m)
	{
		if (newField[m][y] == '@') 
		{
			m = x + 1;
			++newY;
		}
	}

	for (int n = 0; n <= y; ++n)
	{
		if (newField[x][n] == '@')
		{
			n = y + 1;
			++newX;
		}
	}

	for (int v = 0; v <= x; ++v)
	{
		if (newField[v][1] == '@')
		{
			isAliveOnRow = true;
		}
	}

	for (int u = 0; u <= y; ++u)
	{
		if (newField[0][u] == '@')
		{
			isAliveOnColumn = true;
		}
	}
		
	if (isAliveOnColumn)
	{
		newX += 1;
		for (int i = x; i >= 0; --i)
		{
			for (int j = y; j >= 0; --j)
			{
				if (newField[i][j] == '@')
				{
					newField[i][j] = '-';
					newField[i+1][j] = '@';
				}
			}
		}
	}

	if (isAliveOnRow)
	{
		newY += 1;
		for (int i = x; i > 0; --i)
		{
			for (int j = y; j > 0; --j)
			{
				if (newField[i][j] == '@')
				{
					newField[i][j] = '-';
					newField[i][j+1] = '@';
				}
			}
		}
	}


	

	x = (newX <= MAX_WIDTH_SIZE) ? newX : x;
	y = (newY <= MAX_HEIGHT_SIZE) ? newY : y;



	for (int p = 0; p <= x; ++p)
	{
		for (int q = 0; q <= y; ++q)
		{
			field[p][q] = newField[p][q];
		}
	}

}

void killCell(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int x,int y, int previousBorderX, int previousBorderY)
{
	int currentBorderX = x;
	int currentBorderY = y;

		for (int i = 0; i < previousBorderX; ++i)
		{
			for (int j = 0; j < previousBorderY; ++j)
			{
				if (i >= currentBorderX || j >= currentBorderY)
				{
					field[i][j] = '-';
				}
			}
		}
}

void fillField(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int x, int y)
{
	for (int i = 0; i < x; ++i)
	{
		for (int j = 0; j < y; j++)
		{
			field[i][j] = '-';
		}
	}
}

void rowCorrection(int x, int y)   //scales the size
{
	if (x != 1)
	{
		if (y < DOUBLE_DIGIT)
		{
			std::cout << " 1";
		}
		else if (y >= DOUBLE_DIGIT)
		{
			std::cout << " " << " 1";
		}
		for (int i = 1; i < x - 1; ++i)
		{
			std::cout << " ";

		}
		std::cout << x << '\n';
		if (y >= DOUBLE_DIGIT)
		{
			std::cout << " ";
		}
	}
	else
	{
		std::cout << " 1" << '\n';
	}
}

void draw(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int x, int y)
{	
	rowCorrection(x, y);
		for (int i = 1; i <= y; i++)
		{
			if (y < DOUBLE_DIGIT)
			{
				if (i == 1 || i == y)
				{
					std::cout << i;
				}
				else
				{
					std::cout << " ";
				}
			}
			else if (y >= DOUBLE_DIGIT)
			{
				if (i == 1 || i == y)
				{
					std::cout << i;
				}
				else
				{
					std::cout << " " << " ";
				}
			}
			for (int j = 0; j < x; j++)
			{
				std::cout << field[j][i - ADJUSTMENT];
			}
			std::cout << '\n';
		}
		std::cout << '\n';
}

void toggleCell(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int& x,int& y)
{
	int coordX = 0;
	int coordY = 0;

	std::cout << "Type 'x' and 'y'" << '\n';
	std::cin >> coordX >> coordY;

	if ((coordX >= MIN_X && coordX <= x) && (coordY >= MIN_Y && coordY <= y))
	{
		if (field[coordX - ADJUSTMENT][coordY - ADJUSTMENT] == '-')
		{
			field[coordX - ADJUSTMENT][coordY - ADJUSTMENT] = '@';
		}
		else if (field[coordX - ADJUSTMENT][coordY - ADJUSTMENT] == '@')
		{
			field[coordX - ADJUSTMENT][coordY - ADJUSTMENT] = '-';
		}
	}
	else
	{
		std::cout << "Enter valid coordinates!" << '\n';
		toggleCell(field, x, y);
	}
}

void resize(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int& x, int& y)
{
	int previousBorderX = x;
	int previousBorderY = y;

	std::cout << "Select new Height and Width" << '\n';
	std::cin >> x >> y;

	if ((x >= MIN_X && x <= MAX_WIDTH_SIZE) && (y >= MIN_Y && y <= MAX_HEIGHT_SIZE))
	{
		killCell(field, x, y, previousBorderX, previousBorderY);         // kills all cells out of the resized matrix
		draw(field, x, y);
		std::cout << "Current size of the field is " << x << "x" << y << '\n';
	}
	else
	{
		std::cout << "Type x from 1 to 24 and y from 1 to 80!" << '\n';
		resize(field, x, y);
	}
}

void crop(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int& x, int& y,char croppedField[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE])
{
	int upperBound = 0;
	int lowerBound = 0;
	int leftBound = 0;
	int rightBound = 0;

	for (int i = 0; i < x; ++i)                // searches by columns from left to right until it finds the first '@' 
	{
		for (int j = 0; j < y; ++j)
		{
			if (field[i][j] == '@')
			{
				leftBound = i;         // left boundary has coordinate x in which '@' is found;
				i = x;				// leaves the loop
				j = y;
			}
		}
	}

	for (int i = 0; i < y; ++i)         // searches by rows from the upper side until it finds the first '@' 
	{
		for (int j = 0; j < x; ++j)
		{
			if (field[j][i] == '@')
			{
				upperBound = i;  // upper boundary has coordinate y in which '@' is found;
				i = y;		//leaves the loop
				j = x;
			}
		}
	}

	for (int i = x; i >= 0; --i)    // searches by columns right to left until it finds the first '@' 
	{
		for (int j = 0; j < y; ++j)
		{
			if (field[i][j] == '@')
			{
				rightBound = i;   // right boundary has coordinate x in which '@' is found;
				i = 0;			// leaves the loop
				j = y;
			}
		}
	}

	for (int i = y - 1; i >= 0; --i)   // searches by rows from the lower side until it finds the first '@' 
	{
		for (int j = 0; j < x; ++j)
		{
			if (field[j][i] == '@')		
			{
				lowerBound = i;  // lower boundary has coordinate y in which '@' is found;
				i = 0;		//leaves the loop
				j = x;
			}
		}
	}

	for (int i = leftBound; i <= rightBound; ++i)   //crops the matrix and saves the result into a new one
	{
		for (int j = upperBound; j <= lowerBound; ++j)
		{
			croppedField[i - leftBound][j - upperBound] = field[i][j];
		}
	}

	fillField(field, x, y);
	
	for (int i = 0; i <= rightBound - leftBound; ++i)
	{
		for (int j = 0; j <= lowerBound - upperBound; ++j)   //the old matrix gets width and height from the new one
		{
			field[i][j] = croppedField[i][j];
		}
	}

	x = rightBound - leftBound + 1;
	y = lowerBound - upperBound + 1;

}

void randomize(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int x, int y)
{
	srand((unsigned)time(NULL)); // provides different seed so that every random generated server is completely random;

	int N = -1;
	while (N < 0 || std::cin.bad())          //validation
	{
		std::cout << "Enter a number 'N'" << '\n';
		std::cin.clear();
		std::cin.ignore();
		std::cin >> N;
	}

	fillField(field, x, y);

	
	if (N == 0)
	{
		return;
	}

	for (int i = 0; i < x; ++i)
	{
		for (int j = 0; j < y; ++j)
		{
			if (rand() % N == 0)        // generates a random number and every Nth number can be divided by N
			{
				field[i][j] = '@';
			}
		}
	}
}

void gameMenu(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int& x, int& y)
{
	int secondChoice = 0;

	std::cout << "Step forward" << ": type '1'" << '\n';
	std::cout << "Resize" << ": type '2'" << '\n';
	std::cout << "Toggle cell" << ": type '3'" << '\n';
	std::cout << "Clear" << ": type '4'" << '\n';
	std::cout << "Randomize" << ": type '5'" << '\n';
	std::cout << "Save file" << ": type '6'" << '\n';
	std::cout << "End" << ": type '7'" << '\n';

	std::cin >> secondChoice;

	while (std::cin.bad() || secondChoice < 1 || secondChoice > 7)   //validation
	{
		std::cout << "Invalid choice" << '\n';
		std::cin.clear();
		std::cin.ignore();
		std::cin >> secondChoice;
	}

	switch (secondChoice)
	{
	case 1:
		std::cout << "Stepped forward" << '\n';
		stepForward(field, x, y);
		draw(field, x, y);
		gameMenu(field, x, y);
		break;
	case 2:
		std::cout << "Resize" << '\n';
		std::cout << "Current size of the field is " << x << "x" << y << '\n';
		resize(field, x, y);
		gameMenu(field, x, y);
		break;
	case 3:
		toggleCell(field, x, y);
		draw(field, x, y);
		gameMenu(field, x, y);
		break;
	case 4:
		std::cout << "Clear" << '\n';
		fillField(field, x, y);
		draw(field, x, y);
		gameMenu(field, x, y);
		break;
	case 5:
		std::cout << "Randomized" << '\n';
		randomize(field, x, y);
		draw(field, x, y);
		gameMenu(field, x, y);
		break;
	case 6:
		std::cout << "Enter file name" << '\n';
		save(field, x, y);
		draw(field, x, y);
		gameMenu(field, x, y);
		break;
	case 7:
		std::cout << "Returned to Main menu" << '\n';
		mainMenu(field, x, y);
		break;
	}
	
}

void mainMenu(char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE], int& x, int& y)
{
	int firstChoice = 1;

	std::cout << "New Game" << ": type '1'" << '\n';
	std::cout << "Load File" << ": type '2'" << '\n';
	std::cout << "Exit" << ": type '3'" << '\n';

	std::cin >> firstChoice;

	while (std::cin.bad() || firstChoice < 1 || firstChoice > 3)
	{
		std::cout << "Invalid choice" << '\n';
		std::cin.clear();
		std::cin.ignore();
		std::cin >> firstChoice;
	}

		if (firstChoice == 1)
		{
			std::cout << "New game started" << '\n';
			draw(field, x, y);
			gameMenu(field, x, y);
		}
		else if (firstChoice == 2)
		{
			std::cout << "Enter your file name" << '\n';
			load(field, x, y);
			draw(field, x, y);
			gameMenu(field, x, y);
		}
		else if(firstChoice == 3)
		{
			std::cout << "Thanks for playing!";
		}

}

int main()
{
	int x = STARTING_WIDTH; 
	int y = STARTING_HEIGHT; 

	char field[MAX_WIDTH_SIZE][MAX_HEIGHT_SIZE] = {}; 

	fillField(field, MAX_WIDTH_SIZE, MAX_HEIGHT_SIZE);
	mainMenu(field, x, y);

	return 0;
}